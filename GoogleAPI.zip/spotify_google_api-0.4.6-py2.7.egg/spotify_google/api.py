import json
import time

__author__ = 'krantz'

domain = "spotify.com"


class Google(object):
    def __init__(self, httpHandler):
        """
        :type httpHandler: HTTPHandler
        :param httpHandler: HTTP Handler to process all request
        """
        googleapi = "https://www.googleapis.com/admin/directory"
        apiV = "v1"
        self.admin_api_root = "%s/%s" % (googleapi, apiV)
        self.domain = domain
        self.http = httpHandler

    #Group stuff follows
    def group_get(self, group):
        """
        Gets json encoded information about a group
        :rtype : json
        :param group: email address to group
        :return: JSON Response with statusCode of 200 if successful
        """
        uri = "%s/groups/%s" % (self.admin_api_root, group)
        response = self.http.request(uri, "GET")
        return response

    def group_list(self):
        """

        Gets a json encoded list of groups.

        :rtype : json
        :return: JSON Response with all groups. statusCode of 200 if successful.
        """
        uri = "%s/groups?domain=%s" % (self.admin_api_root, domain)
        response = self.http.request(uri, "GET")
        responseOutput = {'groups': [group for group in response.get('groups',[])]}
        while "nextPageToken" in response:
            uri = "%s/groups?domain=%s&pageToken=%s" % (self.admin_api_root, domain, response['nextPageToken'])
            response = self.http.request(uri, "GET")
            responseOutput['groups'] += [group for group in response.get('groups',[])]
        responseOutput['statusCode'] = response['statusCode']
        responseOutput['error'] = response.get('error', None)
        return responseOutput

    def group_post(self, email, name=None, description=None):
        """

        Creates a group with information.
        :rtype : json
        :param email: Email of group
        :param name: Name of group
        :param description: Description of group
        :return: JSON with created group.
        """
        uri = "%s/groups/" % self.admin_api_root
        body = {"email": email}
        if name:
            body['name'] = name
        if description:
            body['description'] = description
        response = self.http.request(uri, "POST", json.dumps(body))
        return response

    def group_delete(self, group):
        """
        Deletes a group

        :rtype : json
        :param group: Email address to group
        :return: JSON object with statusCode 204 in case of success.
        """
        uri = "%s/groups/%s" % (self.admin_api_root, group)
        response = self.http.request(uri, "DELETE")
        return response

    def group_patch(self, group, email=None, name=None, description=None):
        """
        Patch a group

        :rtype : json
        :param group: Email address to group
        :param email: New email address to group
        :param name: New name of group
        :param description: New description of group
        :return: JSON Object with statusCode 200 in case of success
        """
        uri = "%s/groups/%s" % (self.admin_api_root, group)
        body = {}
        if email:
            body['email'] = email
        if name:
            body['name'] = name
        if description:
            body['description'] = description
        response = self.http.request(uri, "PUT", json.dumps(body))
        return response

    #Group aliases

    def group_alias_post(self, group, alias):
        """
        Creates a group alias

        :rtype : json
        :param group: Email address of group
        :param alias: Email address to ALIAS
        :return: JSON Object with a statusCode of 200 in case of success
        """
        uri = "%s/groups/%s/aliases" % (self.admin_api_root, group)
        body = {"alias": alias}
        response = self.http.request(uri, "POST", json.dumps(body))
        return response

    def group_alias_delete(self, group, alias):
        """
        Deletes an alias

        :rtype : json
        :param group: Email address to group
        :param alias: Email address to alias
        :return:
        """
        uri = "%s/groups/%s/aliases/%s" % (self.admin_api_root, group, alias)
        response = self.http.request(uri, "DELETE")
        return response

    def group_alias_list(self, group):
        """
        Gets a list of all aliases for a group.

        :rtype : json
        :param group: Email address to group
        :return: JSON Object with a list. StatusCode of 200 in case of success
        """
        uri = "%s/groups/%s/aliases" % (self.admin_api_root, group)
        response = self.http.request(uri, "GET")
        return response

        #Members to groups

    def group_member_post(self, group, user, role="MEMBER"):
        """
        Add a user to a group

        :rtype : json
        :param group: Email address to group
        :param user: Email address to user
        :param role: Role of member, can be MEMBER, MANAGER, OWNER
        :return: JSON Object with the member added. Statuscode of 200 in case of success.
        """
        uri = "%s/groups/%s/members" % (self.admin_api_root, group)
        if not role in ['MEMBER', 'MANAGER', 'OWNER']:
            return "Role is not MEMBER, MANAGER or OWNER"
        body = {"email": user, "role": role}
        response = self.http.request(uri, "POST", json.dumps(body))
        return response

    def group_member_patch(self, group, user, role="MEMBER"):
        """
        Patch a group member

        :rtype : json
        :param group: Email address to a group
        :param user: Email address to a member of group
        :param role: new role of member, can be MEMBER, MANAGER, OWNER
        :return: JSON Object with the member patched. Statuscode of 200 in case of success.
        """
        uri = "%s/groups/%s/members/%s" % (self.admin_api_root, group, user)
        if not role in ['MEMBER', 'MANAGER', 'OWNER']:
            return "Role is not MEMBER, MANAGER or OWNER"
        body = {"role": role}
        #Although this is using patch semantics, the google API doesn't seem to support the HTTP Verb PATCH
        response = self.http.request(uri, "PUT", json.dumps(body))
        return response

    def group_member_get(self, group, user):
        """

        Get a group member
        :rtype : json
        :param group: Email address to a group
        :param user: Email address to a member of group
        :return: JSON Object with the member patched. Statuscode of 200 in case of success.
        """
        uri = "%s/groups/%s/members/%s" % (self.admin_api_root, group, user)
        response = self.http.request(uri, "GET")
        return response

    def group_member_list(self, group):
        """

        Get all members in a group
        :rtype : json
        :param group: Email address to a group
        :return: JSON Object with list of all members in group. Statuscode of 200 in case of success.
        """
        uri = "%s/groups/%s/members" % (self.admin_api_root, group)
        response = self.http.request(uri, "GET")
        responseOutput = dict()
        if 'members' in response:
            responseOutput = {'members': [member for member in response['members']]}
        while "nextPageToken" in response:
            uri_next = "%s?pageToken=%s" % (uri, response['nextPageToken'])
            response = self.http.request(uri_next, "GET")
            responseOutput['members'] += [member for member in response['members']]
        responseOutput['statusCode'] = response['statusCode']
        responseOutput['error'] = response.get('error', None)
        return responseOutput

    def group_member_delete(self, group, user):
        """


        :rtype : json
        :param group: Email address to a group
        :param user: Email address to a member of group
        :return: JSON Object with Statuscode of 204 in case of success.
        """
        uri = "%s/groups/%s/members/%s" % (self.admin_api_root, group, user)
        response = self.http.request(uri, "DELETE")
        return response

    #User stuff follows
    def user_post(self, email, firstName, lastName, password):
        """
        Creates a user.

        :rtype : json
        :param email: Email of new user.
        :param firstName: Firstname of new user.
        :param lastName: Lastname of new user.
        :param password: Password of new user.
        :return: JSON Object containing created user with statusCode 200 in case of success.
        """
        uri = "%s/users" % self.admin_api_root

        body = {
            "primaryEmail": email,
            "name": {
                "givenName": firstName,
                "familyName": lastName,
            },
            "password": password,
            "changePasswordAtNextLogin": True
        }

        response = self.http.request(uri, "POST", json.dumps(body))

        print "Generating Verification Codes..."
        time.sleep(3)
        verification_codes_response = self.generate_verification_codes(email)
        time.sleep(3)
        verification_codes_response = self.list_verification_codes(email)

        print "One Time Password:", verification_codes_response['items'][0]['verificationCode']

        return response

    def user_delete(self, user):
        """
        Deletes a user. Can be recovered for 5 days using user_undelete(according to google)

        :rtype : json
        :param user: Email address to user
        :return: JSON Object with 204 in case of success.
        """
        uri = "%s/users/%s" % (self.admin_api_root, user)
        response = self.http.request(uri, "DELETE")
        return response

    def user_patch(self, user, firstName=None, lastName=None, password=None, email=None, ou=None):
        """
        Patches user.

        :rtype : json
        :param user: Email address to user
        :param firstName: New firstname of user
        :param lastName: New lastname of user
        :param password: New password of user
        :param email: new Email address of user.
        :return: JSON Object with patched user. 200 in case of success.
        """
        uri = "%s/users/%s" % (self.admin_api_root, user)
        body = {}
        if firstName or lastName:
            body['name'] = {}
        if firstName:
            body['name']['givenName'] = firstName
        if lastName:
            body['name']['familyName'] = lastName
        if password:
            body['password'] = password
        if email:
            body['email'] = email
        if ou:
            body['orgUnitPath'] = ou

        response = self.http.request(uri, "PATCH", json.dumps(body))
        return response

    def user_get(self, user):

        """
        Gets user.

        :rtype : json
        :param user: Get user information.
        :return: JSON Object with user. 200 in case of success.
        """
        uri = "%s/users/%s" % (self.admin_api_root, user)
        response = self.http.request(uri, "GET")
        return response

    # def user_get_groups(self, user):
    #     """
    #     Get all groups the user is a member off.
    #
    #     :rtype : json
    #     :param user: Email address of user
    #     :return: JSON Object with groups, statusCode 200 in case of success.
    #     """
    #     uri = "%s/groups?userKey=%s" % (self.admin_api_root, user)
    #     response = self.http.request(uri, "GET")
    #     return response

    def user_list(self):
        """

        Gets all user in domain

        :rtype : json
        :return: JSON object with all users, statusCode 200 in case of success.
        """
        uri = "%s/users?domain=%s" % (self.admin_api_root, self.domain)
        response = self.http.request(uri, "GET")
        responseOutput = {'users': [user for user in response['users']]}
        while "nextPageToken" in response:
            uri = "%s/users?domain=%s&pageToken=%s&maxResults=500" % (self.admin_api_root, domain, response['nextPageToken'])
            response = self.http.request(uri, "GET")
            responseOutput['users'] += [user for user in response.get('users',[])]
        responseOutput['statusCode'] = response['statusCode']
        responseOutput['error'] = response.get('error', None)
        return responseOutput

    def user_admin_post(self, user, isAdmin):
        """
        Promote or demote to admin.

        :rtype : json
        :param user: Email address to user
        :param isAdmin: Boolean for making admin or demoting from admin.
        :return: JSON Response containing statusCode of 204 in case of success.
        """
        uri = "%s/users/%s/makeAdmin" % (self.admin_api_root, user)
        body = {"status": bool(isAdmin)}
        response = self.http.request(uri, "POST", json.dumps(body))
        return response

    def user_alias_list(self, user):
        """
        Get a list of aliases.
        :rtype : json
        :param user: Email address to user
        :return: JSON Object containing list. statusCode of 200 in case of success.
        """
        uri = "%s/users/%s/aliases" % (self.admin_api_root, user)
        response = self.http.request(uri, "GET")
        return response

    def user_alias_delete(self, user, alias):
        """

        Deletes a user's alias.
        :rtype : json
        :param user: Email address to user
        :param alias: Email address to alias belonging to user
        :return: JSON Object containing statusCode 204 in case of success.
        """
        uri = "%s/users/%s/aliases/%s" % (self.admin_api_root, user, alias)
        response = self.http.request(uri, "DELETE")
        return response

    def user_alias_post(self, user, alias):
        """
        Creates a user alias.

        :rtype : json
        :param user: Email address to user
        :param alias: Email address to an alias.
        :return: JSON Object containing the user alias. statusCode of 200 in case of success.
        """
        uri = "%s/users/%s/aliases" % (self.admin_api_root, user)
        body = {"alias": alias}
        response = self.http.request(uri, "POST", json.dumps(body))
        return response

    def user_group_list(self, user):
        """
        Get all groups the user is a member off.

        :rtype : json
        :param user: Email address of user
        :return: JSON Object with groups, statusCode 200 in case of success.
        """
        uri = "%s/groups?userKey=%s" % (self.admin_api_root, user)
        response = self.http.request(uri, "GET")
        responseOutput = {'users': [group for group in response.get('groups', [])]}
        while "nextPageToken" in response:
            uri = "%s/users?domain=%s&pageToken=%s" % (self.admin_api_root, domain, response['nextPageToken'])
            response = self.http.request(uri, "GET")
            responseOutput['groups'] += [group for group in response.get('groups', [])]
        responseOutput['statusCode'] = response['statusCode']
        responseOutput['error'] = response.get('error', None)
        return responseOutput

    def user_suspend(self, user):
        """
        Suspend a user

        :rtype : json
        :param user: Email address to user
        :return: JSON Object with User, statusCode 200 in case of success.
        """
        uri = "%s/users/%s" % (self.admin_api_root, user)
        body = {'suspended': True}
        return self.http.request(uri, "PUT", json.dumps(body))

    def user_restore(self, user):
        """
        Restore a user

        :rtype : json
        :param user: Email address to user.
        :return: JSON Object with User, statusCode 200 in case of success.
        """
        uri = "%s/users/%s" % (self.admin_api_root, user)
        body = {'suspended': False}
        return self.http.request(uri, "PUT", json.dumps(body))

    def user_deleted_list(self):
        """
        Get a list of all deleted users.

        :rtype : json
        :return: A JSON Object with List containing deleted users
        """
        uri = "%s/users/?domain=%s&showDeleted=true" % (self.admin_api_root, self.domain)
        response = self.http.request(uri, "GET")
        responseOutput = {'users': [user for user in response['users']]}
        while "nextPageToken" in response:
            uri_next = "%s&pageToken=%s" % (uri, response['nextPageToken'])
            response = self.http.request(uri_next, "GET")
            responseOutput['users'] += [user for user in response['users']]
        responseOutput['statusCode'] = response['statusCode']
        responseOutput['error'] = response.get('error', None)
        return responseOutput

    def user_undelete(self, userkey):
        """
        Undeleted a user

        :rtype : json
        :param userkey: The unique identifier of a certain user. (Not email address)
        :return: JSON Object with statusCode 200 in case of success.
        """
        uri = "%s/users/%s/undelete" % (self.admin_api_root, userkey)
        response = self.http.request(uri, "POST")
        return response

    def generate_verification_codes(self, username):
        uri = self.admin_api_root + '/users/{0}/verificationCodes/generate'.format(username)
        response = self.http.request(uri, 'POST')
        return response

    def list_verification_codes(self, username):
        uri = self.admin_api_root + '/users/{0}/verificationCodes'.format(username)
        response = self.http.request(uri, 'GET')
        return response
