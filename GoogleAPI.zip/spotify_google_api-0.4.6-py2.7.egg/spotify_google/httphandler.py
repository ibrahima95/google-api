import getpass
import json
import httplib2
from oauth2client.client import flow_from_clientsecrets
from oauth2client.keyring_storage import Storage
from oauth2client import tools

filename = __file__

__author__ = 'krantz'

class HTTPHandler(object):
    def __init__(self, args):
        path = filename.rsplit('/', 1)[0]
        flow = flow_from_clientsecrets('%s/client_secrets.json' % path,
                                       scope="https://www.googleapis.com/auth/admin.directory.group https://www.googleapis.com/auth/admin.directory.user https://www.googleapis.com/auth/admin.directory.orgunit.readonly https://www.googleapis.com/auth/admin.directory.user.security",
                                       redirect_uri='http://localhost')

        storage = Storage('GoogleAdminAPI', getpass.getuser())
        credentials = storage.get()
        if credentials is None or credentials.invalid:
            credentials = tools.run_flow(flow, storage, args)
        http = httplib2.Http()
        self.http = credentials.authorize(http)

    def request(self, uri, method="GET", body=None):
        """
        :rtype : json
        :param uri: URI for request to be applied to
        :param method: HTTP verb to use for request
        :param body: Body of request
        :return: JSON encoded response
        """
        if body:
            resp, content = self.http.request(uri, method=method, body=body,
                                              headers={'Content-Type': 'application/json; charset=UTF-8'})
        elif not body and method == "POST":
            resp, content = self.http.request(uri, method=method, body="{}",
                                              headers={'Content-Type': 'application/json; charset=UTF-8'})
        else:
            resp, content = self.http.request(uri, method=method)
        if content:
            content = json.loads(content.decode('utf-8'))
        else:
            content = {}
        content['statusCode'] = resp['status']
        return content
